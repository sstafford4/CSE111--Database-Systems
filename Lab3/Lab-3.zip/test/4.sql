.headers on

-- returns the names of the suppliers given that their account balance is >= 8000

SELECT s_name
from supplier
where s_acctbal > 8000;